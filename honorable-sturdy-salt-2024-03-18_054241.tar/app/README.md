# To Make a Dadaist Poem

A simple text reassembler based on Tristan Tzara's "To Make a Dadaist Poem"
